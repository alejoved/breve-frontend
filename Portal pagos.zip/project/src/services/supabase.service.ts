import { Injectable } from '@angular/core';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { Plan, Subscription, Invoice } from '../models/subscription.model';

@Injectable({
  providedIn: 'root'
})
export class SupabaseService {
  private supabase: SupabaseClient;

  constructor() {
    const supabaseUrl = 'https://rgccrpzlmncedkqdaddz.supabase.co';
    const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJnY2NycHpsbW5jZWRrcWRhZGR6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjI3ODYwNjYsImV4cCI6MjA3ODM2MjA2Nn0.uFdZwhWpapLHZaJm6X0xTNZtAXuxkMuIbgh6aM_4Zng';

    this.supabase = createClient(supabaseUrl, supabaseKey);
  }

  async getSubscriptionByIdentification(identificationNumber: string): Promise<Subscription | null> {
    const subscriptions = await this.getSubscriptionsByIdentification(identificationNumber);
    return subscriptions.length > 0 ? subscriptions[0] : null;
  }

  async getSubscriptionsByIdentification(identificationNumber: string): Promise<Subscription[]> {
    const { data, error } = await this.supabase
      .from('subscriptions')
      .select(`
        *,
        plan:plans(
          *,
          business:businesses(*)
        )
      `)
      .eq('identification_number', identificationNumber)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error fetching subscriptions:', error);
      return [];
    }

    return data || [];
  }

  async getInvoicesBySubscription(subscriptionId: string): Promise<Invoice[]> {
    const { data, error } = await this.supabase
      .from('invoices')
      .select('*')
      .eq('subscription_id', subscriptionId)
      .order('due_date', { ascending: false });

    if (error) {
      console.error('Error fetching invoices:', error);
      return [];
    }

    return data || [];
  }

  async getAllPlans(): Promise<Plan[]> {
    const { data, error } = await this.supabase
      .from('plans')
      .select('*')
      .order('price', { ascending: true });

    if (error) {
      console.error('Error fetching plans:', error);
      return [];
    }

    return data || [];
  }

  async updateSubscriptionPlan(subscriptionId: string, newPlanId: string): Promise<boolean> {
    const { error } = await this.supabase
      .from('subscriptions')
      .update({
        plan_id: newPlanId,
        updated_at: new Date().toISOString()
      })
      .eq('id', subscriptionId);

    if (error) {
      console.error('Error updating subscription:', error);
      return false;
    }

    return true;
  }
}
