export interface Business {
  id: string;
  name: string;
  logo_url: string;
}

export interface Plan {
  id: string;
  name: string;
  price: number;
  features: string[];
  is_popular: boolean;
  business_id?: string;
  business?: Business;
}

export interface Subscription {
  id: string;
  identification_number: string;
  plan_id: string;
  status: string;
  start_date: string;
  next_billing_date: string;
  plan?: Plan;
  business?: Business;
}

export interface Invoice {
  id: string;
  subscription_id: string;
  invoice_number: string;
  amount: number;
  issue_date: string;
  due_date: string;
  status: string;
}
