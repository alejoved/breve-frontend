import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { SupabaseService } from '../../services/supabase.service';
import { Subscription, Invoice } from '../../models/subscription.model';

@Component({
  selector: 'app-subscriptions',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './subscriptions.component.html',
  styleUrls: ['./subscriptions.component.css']
})
export class SubscriptionsComponent implements OnInit {
  subscriptions: Subscription[] = [];
  subscriptionInvoices: Map<string, Invoice[]> = new Map();
  isLoading: boolean = true;
  identificationNumber: string = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private supabaseService: SupabaseService
  ) {}

  async ngOnInit() {
    this.identificationNumber = this.route.snapshot.paramMap.get('id') || '';

    if (!this.identificationNumber) {
      this.router.navigate(['/']);
      return;
    }

    await this.loadSubscriptionData();
  }

  async loadSubscriptionData() {
    this.isLoading = true;

    try {
      this.subscriptions = await this.supabaseService.getSubscriptionsByIdentification(this.identificationNumber);

      if (this.subscriptions.length > 0) {
        for (const subscription of this.subscriptions) {
          const invoices = await this.supabaseService.getInvoicesBySubscription(subscription.id);
          this.subscriptionInvoices.set(subscription.id, invoices);
        }
      } else {
        this.router.navigate(['/']);
      }
    } catch (error) {
      console.error('Error loading subscriptions:', error);
      this.router.navigate(['/']);
    } finally {
      this.isLoading = false;
    }
  }

  goBack() {
    this.router.navigate(['/']);
  }

  editPlan(subscriptionId: string) {
    this.router.navigate(['/modify-plan', this.identificationNumber], {
      queryParams: { subscription: subscriptionId }
    });
  }

  getInvoicesForSubscription(subscriptionId: string): Invoice[] {
    return this.subscriptionInvoices.get(subscriptionId) || [];
  }

  formatCurrency(amount: number): string {
    return `$${amount.toLocaleString('es-CO')}`;
  }

  formatDate(date: string): string {
    const d = new Date(date);
    const day = d.getDate();
    const months = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
                    'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
    const month = months[d.getMonth()];
    const year = d.getFullYear();
    return `${day} de ${month} de ${year}`;
  }

  onPagar(invoice: Invoice) {
    alert(`Procesando pago de ${this.formatCurrency(invoice.amount)} para factura ${invoice.invoice_number}`);
  }
}
