import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { SupabaseService } from '../../services/supabase.service';
import { Plan, Subscription } from '../../models/subscription.model';

@Component({
  selector: 'app-modify-plan',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './modify-plan.component.html',
  styleUrls: ['./modify-plan.component.css']
})
export class ModifyPlanComponent implements OnInit {
  plans: Plan[] = [];
  subscription: Subscription | null = null;
  selectedPlanId: string = '';
  identificationNumber: string = '';
  isLoading: boolean = true;
  isSaving: boolean = false;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private supabaseService: SupabaseService
  ) {}

  async ngOnInit() {
    this.identificationNumber = this.route.snapshot.paramMap.get('id') || '';

    if (!this.identificationNumber) {
      this.router.navigate(['/']);
      return;
    }

    await this.loadData();
  }

  async loadData() {
    this.isLoading = true;

    try {
      this.subscription = await this.supabaseService.getSubscriptionByIdentification(this.identificationNumber);
      this.plans = await this.supabaseService.getAllPlans();

      if (this.subscription) {
        this.selectedPlanId = this.subscription.plan_id;
      } else {
        this.router.navigate(['/']);
      }
    } catch (error) {
      console.error('Error loading data:', error);
      this.router.navigate(['/']);
    } finally {
      this.isLoading = false;
    }
  }

  goBack() {
    this.router.navigate(['/subscriptions', this.identificationNumber]);
  }

  selectPlan(planId: string) {
    this.selectedPlanId = planId;
  }

  async onSaveChanges() {
    if (!this.subscription || this.selectedPlanId === this.subscription.plan_id) {
      this.goBack();
      return;
    }

    this.isSaving = true;

    try {
      const success = await this.supabaseService.updateSubscriptionPlan(this.subscription.id, this.selectedPlanId);

      if (success) {
        this.router.navigate(['/subscriptions', this.identificationNumber]);
      } else {
        alert('No se pudo actualizar el plan. Por favor intenta de nuevo.');
      }
    } catch (error) {
      console.error('Error updating plan:', error);
      alert('Ocurrió un error al actualizar el plan.');
    } finally {
      this.isSaving = false;
    }
  }

  formatCurrency(amount: number): string {
    return `$${amount.toLocaleString('es-CO')}/mes`;
  }

  canSave(): boolean {
    return !this.isSaving && this.selectedPlanId !== '' &&
           this.selectedPlanId !== this.subscription?.plan_id;
  }
}
