import { Component, OnInit, OnDestroy, ElementRef, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { SupabaseService } from '../../services/supabase.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, OnDestroy {
  @ViewChild('gradientCanvas', { static: false }) canvasRef!: ElementRef<HTMLCanvasElement>;

  identificationNumber: string = '';
  isLoading: boolean = false;
  errorMessage: string = '';
  private gradient: any;

  constructor(
    private supabaseService: SupabaseService,
    private router: Router
  ) {}

  ngOnInit() {
    setTimeout(() => {
      if (this.canvasRef) {
        this.initGradient();
      }
    });
  }

  ngOnDestroy() {
    if (this.gradient) {
      this.gradient.destroy();
    }
  }

  private initGradient() {
    const canvas = this.canvasRef.nativeElement;
    this.gradient = new (window as any).MeshGradient(canvas, {
      colors: [
        'hsl(266, 100%, 64%)',
        'hsl(266, 100%, 64%)',
        'hsl(266, 100%, 64%)',
        'hsl(266, 100%, 64%)'
      ],
      speed: 5
    });
  }

  async onConsultar() {
    if (!this.identificationNumber.trim()) {
      this.errorMessage = 'Por favor ingresa tu número de identificación';
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    try {
      const subscription = await this.supabaseService.getSubscriptionByIdentification(this.identificationNumber);

      if (subscription) {
        this.router.navigate(['/subscriptions', this.identificationNumber]);
      } else {
        this.errorMessage = 'No se encontró ninguna suscripción con este número de identificación';
      }
    } catch (error) {
      this.errorMessage = 'Ocurrió un error al consultar. Por favor intenta de nuevo.';
    } finally {
      this.isLoading = false;
    }
  }
}
