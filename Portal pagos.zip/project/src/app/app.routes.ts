import { Routes } from '@angular/router';
import { HomeComponent } from '../components/home/home.component';
import { SubscriptionsComponent } from '../components/subscriptions/subscriptions.component';
import { ModifyPlanComponent } from '../components/modify-plan/modify-plan.component';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'subscriptions/:id', component: SubscriptionsComponent },
  { path: 'modify-plan/:id', component: ModifyPlanComponent },
  { path: '**', redirectTo: '' }
];
