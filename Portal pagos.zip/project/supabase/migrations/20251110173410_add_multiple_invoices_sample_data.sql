/*
  # Add Multiple Invoices Sample Data

  1. Changes
    - Add a second invoice for the existing subscription (12345678)
    - This demonstrates multiple pending payments for a single user
  
  2. Notes
    - Both invoices will be in pending status
    - Different amounts and due dates to show variety
*/

DO $$
DECLARE
  subscription_id uuid;
BEGIN
  SELECT id INTO subscription_id FROM subscriptions WHERE identification_number = '12345678' LIMIT 1;
  
  IF subscription_id IS NOT NULL THEN
    INSERT INTO invoices (subscription_id, invoice_number, amount, issue_date, due_date, status)
    VALUES 
      (subscription_id, 'INV-2024-002', 89000, '2025-11-09', '2025-11-25', 'pending')
    ON CONFLICT (invoice_number) DO NOTHING;
  END IF;
END $$;
