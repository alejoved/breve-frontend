/*
  # Payment Portal Schema for +Breve

  1. New Tables
    - `plans`
      - `id` (uuid, primary key)
      - `name` (text) - Plan name (e.g., "Plan Básico", "Plan Premium")
      - `price` (numeric) - Monthly price
      - `features` (jsonb) - Array of features included in the plan
      - `is_popular` (boolean) - Whether this plan is marked as popular
      - `created_at` (timestamptz)
    
    - `subscriptions`
      - `id` (uuid, primary key)
      - `identification_number` (text) - User identification number
      - `plan_id` (uuid) - Foreign key to plans
      - `status` (text) - Subscription status (active, inactive, cancelled)
      - `start_date` (date) - Subscription start date
      - `next_billing_date` (date) - Next billing date
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)
    
    - `invoices`
      - `id` (uuid, primary key)
      - `subscription_id` (uuid) - Foreign key to subscriptions
      - `invoice_number` (text) - Invoice identifier (e.g., "INV-2024-001")
      - `amount` (numeric) - Invoice amount
      - `issue_date` (date) - Date when invoice was issued
      - `due_date` (date) - Payment due date
      - `status` (text) - Payment status (pending, paid, overdue)
      - `created_at` (timestamptz)
  
  2. Security
    - Enable RLS on all tables
    - Add policies for public read access (no authentication required for this portal)
  
  3. Sample Data
    - Insert two plans: Plan Básico and Plan Premium
    - Insert sample subscription and invoice for testing
*/

-- Create plans table
CREATE TABLE IF NOT EXISTS plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  price numeric NOT NULL,
  features jsonb NOT NULL DEFAULT '[]'::jsonb,
  is_popular boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create subscriptions table
CREATE TABLE IF NOT EXISTS subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  identification_number text NOT NULL UNIQUE,
  plan_id uuid REFERENCES plans(id) NOT NULL,
  status text NOT NULL DEFAULT 'active',
  start_date date NOT NULL,
  next_billing_date date NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create invoices table
CREATE TABLE IF NOT EXISTS invoices (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subscription_id uuid REFERENCES subscriptions(id) NOT NULL,
  invoice_number text NOT NULL UNIQUE,
  amount numeric NOT NULL,
  issue_date date NOT NULL,
  due_date date NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoices ENABLE ROW LEVEL SECURITY;

-- Create policies for public access (no authentication required)
CREATE POLICY "Anyone can view plans"
  ON plans FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can view subscriptions"
  ON subscriptions FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Anyone can update subscriptions"
  ON subscriptions FOR UPDATE
  TO public
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can view invoices"
  ON invoices FOR SELECT
  TO public
  USING (true);

-- Insert sample plans
INSERT INTO plans (name, price, features, is_popular) VALUES
  ('Plan Básico', 89000, '["Acceso al gimnasio.", "Vestuarios", "1 clase grupal/semana"]'::jsonb, false),
  ('Plan Premium', 129000, '["Acceso al gimnasio.", "Clases grupales ilimitadas", "Entrenador personal 2h/mes", "Nutricionista"]'::jsonb, true)
ON CONFLICT DO NOTHING;

-- Insert sample subscription
DO $$
DECLARE
  plan_basico_id uuid;
  subscription_id uuid;
BEGIN
  SELECT id INTO plan_basico_id FROM plans WHERE name = 'Plan Básico' LIMIT 1;
  
  IF plan_basico_id IS NOT NULL THEN
    INSERT INTO subscriptions (identification_number, plan_id, status, start_date, next_billing_date)
    VALUES ('12345678', plan_basico_id, 'active', '2025-05-09', '2025-12-09')
    ON CONFLICT (identification_number) DO NOTHING
    RETURNING id INTO subscription_id;
    
    IF subscription_id IS NOT NULL THEN
      INSERT INTO invoices (subscription_id, invoice_number, amount, issue_date, due_date, status)
      VALUES (subscription_id, 'INV-2024-001', 150000, '2025-10-09', '2025-10-25', 'pending')
      ON CONFLICT (invoice_number) DO NOTHING;
    END IF;
  END IF;
END $$;