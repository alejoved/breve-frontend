/*
  # Add Business Support and Multiple Subscriptions per User

  1. Changes
    - Add `businesses` table to store business information (name, logo URL)
    - Modify `plans` table to add `business_id` foreign key
    - Remove UNIQUE constraint on `subscriptions.identification_number` to allow multiple subscriptions per user
    - Add sample business data (Gym and Spa)
    - Add second subscription for the test user
  
  2. New Tables
    - `businesses`
      - `id` (uuid, primary key)
      - `name` (text) - Business name
      - `logo_url` (text) - URL to business logo
      - `created_at` (timestamptz)
  
  3. Security
    - Enable RLS on businesses table
    - Add policy for public read access
*/

-- Create businesses table
CREATE TABLE IF NOT EXISTS businesses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  logo_url text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE businesses ENABLE ROW LEVEL SECURITY;

-- Create policy for public access
CREATE POLICY "Anyone can view businesses"
  ON businesses FOR SELECT
  TO public
  USING (true);

-- Add business_id to plans table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'plans' AND column_name = 'business_id'
  ) THEN
    ALTER TABLE plans ADD COLUMN business_id uuid REFERENCES businesses(id);
  END IF;
END $$;

-- Drop UNIQUE constraint on subscriptions.identification_number to allow multiple subscriptions
ALTER TABLE subscriptions DROP CONSTRAINT IF EXISTS subscriptions_identification_number_key;

-- Insert sample businesses
INSERT INTO businesses (name, logo_url) VALUES
  ('FitLife Gym', 'assets/Logo +Breve.png'),
  ('Relax Spa & Wellness', 'assets/Logo +Breve.png')
ON CONFLICT DO NOTHING;

-- Update existing plans with business_id and add new plans for second business
DO $$
DECLARE
  gym_id uuid;
  spa_id uuid;
  plan_yoga_id uuid;
  subscription_id uuid;
BEGIN
  SELECT id INTO gym_id FROM businesses WHERE name = 'FitLife Gym' LIMIT 1;
  SELECT id INTO spa_id FROM businesses WHERE name = 'Relax Spa & Wellness' LIMIT 1;
  
  IF gym_id IS NOT NULL THEN
    UPDATE plans SET business_id = gym_id WHERE name IN ('Plan Básico', 'Plan Premium');
  END IF;
  
  IF spa_id IS NOT NULL THEN
    INSERT INTO plans (name, price, features, is_popular, business_id)
    VALUES ('Plan Yoga Mensual', 120000, '["Clases de yoga ilimitadas", "Acceso a sauna", "Toalla incluida", "Estacionamiento gratuito"]'::jsonb, false, spa_id)
    ON CONFLICT DO NOTHING
    RETURNING id INTO plan_yoga_id;
    
    IF plan_yoga_id IS NOT NULL THEN
      INSERT INTO subscriptions (identification_number, plan_id, status, start_date, next_billing_date)
      VALUES ('12345678', plan_yoga_id, 'active', '2025-06-01', '2025-12-01')
      RETURNING id INTO subscription_id;
      
      IF subscription_id IS NOT NULL THEN
        INSERT INTO invoices (subscription_id, invoice_number, amount, issue_date, due_date, status)
        VALUES (subscription_id, 'INV-SPA-2024-001', 120000, '2025-11-01', '2025-11-15', 'pending')
        ON CONFLICT (invoice_number) DO NOTHING;
      END IF;
    END IF;
  END IF;
END $$;
